/**
 * Mode 6 Intent Router
 * 
 * Central routing engine that:
 * 1. Receives task intents from Linear/user input
 * 2. Analyzes task context and requirements
 * 3. Routes to appropriate agent based on capability matrix
 * 4. Coordinates multi-agent handoffs with context preservation
 * 
 * Follows multi-agent-sop.md handoff protocol
 */

import { AgentType, TaskIntent, RoutingDecision, HandoffContext } from './types';
import { AgentDispatcher } from '../agent-routing/agent-dispatcher';
import { MemoryManager } from '../memory/memory-manager';

export class IntentRouter {
  private dispatcher: AgentDispatcher;
  private memory: MemoryManager;
  private routingLog: Array<{ timestamp: string; intent: TaskIntent; decision: RoutingDecision }> = [];

  constructor(dispatcher: AgentDispatcher, memory: MemoryManager) {
    this.dispatcher = dispatcher;
    this.memory = memory;
  }

  /**
   * Main routing entry point
   * Accepts task intent and determines optimal agent + handoff protocol
   */
  async routeIntent(intent: TaskIntent): Promise<HandoffContext> {
    const startTime = new Date();
    
    try {
      // 1. Analyze intent and extract requirements
      const analysis = this.analyzeIntent(intent);

      // 2. Determine primary agent based on task type
      const primaryAgent = this.selectPrimaryAgent(analysis);

      // 3. Check for multi-agent coordination needs
      const secondaryAgents = this.identifySecondaryAgents(analysis, primaryAgent);

      // 4. Build routing decision with full context
      const decision: RoutingDecision = {
        intentId: intent.id,
        primaryAgent,
        secondaryAgents,
        reasoning: `Task type: ${analysis.taskType}, Complexity: ${analysis.complexity}`,
        escalationPath: this.getEscalationPath(primaryAgent),
        contextWindowRequired: analysis.contextSize,
      };

      // 5. Prepare handoff context (from multi-agent-sop.md pattern)
      const handoff = await this.prepareHandoff(intent, decision);

      // 6. Log routing decision
      this.logRoutingDecision(intent, decision);

      // 7. Store in memory for cross-agent reference
      await this.memory.storeRoutingDecision(decision);

      return handoff;
    } catch (error) {
      console.error(`Intent routing failed for ${intent.id}:`, error);
      throw error;
    }
  }

  /**
   * Analyze intent to extract task characteristics
   */
  private analyzeIntent(intent: TaskIntent): IntentAnalysis {
    return {
      taskType: this.classifyTaskType(intent),
      complexity: this.estimateComplexity(intent),
      contextSize: this.estimateContextSize(intent),
      requiresResearch: intent.description.toLowerCase().includes('research') ||
                       intent.description.toLowerCase().includes('verify'),
      requiresCodeGeneration: intent.description.toLowerCase().includes('code') ||
                             intent.description.toLowerCase().includes('implement'),
      requiresOrchestration: intent.subtasks && intent.subtasks.length > 1,
    };
  }

  /**
   * Classify task into categories matching agent capabilities
   * From multi-agent-sop.md agent routing
   */
  private classifyTaskType(intent: TaskIntent): string {
    const description = intent.description.toLowerCase();

    if (description.includes('orchestr') || description.includes('coord')) {
      return 'orchestration';
    }
    if (description.includes('research') || description.includes('verify') || description.includes('browse')) {
      return 'research';
    }
    if (description.includes('code') || description.includes('implement') || description.includes('generate')) {
      return 'development';
    }
    if (description.includes('git') || description.includes('commit') || description.includes('github')) {
      return 'github-integration';
    }
    return 'analysis';
  }

  /**
   * Estimate task complexity (quick/complex/urgent)
   */
  private estimateComplexity(intent: TaskIntent): 'quick' | 'complex' | 'urgent' {
    const hasSubtasks = intent.subtasks && intent.subtasks.length > 0;
    const isPriority = intent.priority === 'high' || intent.priority === 'critical';

    if (isPriority && !hasSubtasks) return 'urgent';
    if (hasSubtasks) return 'complex';
    return 'quick';
  }

  /**
   * Estimate context window needed for task completion
   */
  private estimateContextSize(intent: TaskIntent): number {
    let size = intent.description.length;
    if (intent.subtasks) size += intent.subtasks.reduce((sum, st) => sum + st.length, 0);
    return size;
  }

  /**
   * Select primary agent based on task analysis
   * From multi-agent-sop.md agent matrix
   */
  private selectPrimaryAgent(analysis: IntentAnalysis): AgentType {
    if (analysis.taskType === 'orchestration' || analysis.complexity === 'complex') {
      return 'supergrok'; // Central orchestration
    }
    if (analysis.taskType === 'research' && analysis.requiresResearch) {
      return 'comet'; // Research & verification
    }
    if (analysis.taskType === 'github-integration') {
      return 'chatgpt'; // GitHub integration
    }
    if (analysis.taskType === 'development' && analysis.requiresCodeGeneration) {
      return 'claude'; // Code generation
    }
    return 'claude'; // Default to Claude for analysis
  }

  /**
   * Identify if secondary agents needed (multi-agent pattern)
   */
  private identifySecondaryAgents(analysis: IntentAnalysis, primary: AgentType): AgentType[] {
    const secondary: AgentType[] = [];

    if (analysis.requiresResearch && primary !== 'comet') {
      secondary.push('comet');
    }
    if (analysis.requiresCodeGeneration && primary !== 'claude') {
      secondary.push('claude');
    }
    if (analysis.complexity === 'complex' && primary !== 'supergrok') {
      secondary.push('supergrok');
    }

    return secondary;
  }

  /**
   * Get escalation path for agent (from multi-agent-sop.md)
   */
  private getEscalationPath(agent: AgentType): string {
    const escalationMap: Record<AgentType, string> = {
      claude: 'supergrok → human-review',
      supergrok: 'human-decision-point',
      comet: 'claude → supergrok',
      chatgpt: 'claude → human-review',
    };
    return escalationMap[agent];
  }

  /**
   * Prepare handoff context following multi-agent-sop.md protocol
   */
  private async prepareHandoff(intent: TaskIntent, decision: RoutingDecision): Promise<HandoffContext> {
    const context = await this.memory.retrieveRelatedContext(intent.id);

    return {
      format: `[MODE6_ROUTER] → [${decision.primaryAgent.toUpperCase()}]`,
      context: {
        fullTaskDescription: intent.description,
        subtasks: intent.subtasks || [],
        relatedContext: context,
        linearTicket: intent.linearId,
      },
      expectedOutput: {
        format: 'structured-result',
        includeMetadata: true,
      },
      escalationRoute: decision.escalationPath,
      timestamp: new Date().toISOString(),
    };
  }

  /**
   * Log routing decision for audit trail
   */
  private logRoutingDecision(intent: TaskIntent, decision: RoutingDecision): void {
    this.routingLog.push({
      timestamp: new Date().toISOString(),
      intent,
      decision,
    });

    console.log(`[MODE6] Routed intent ${intent.id} to ${decision.primaryAgent}`);
  }

  /**
   * Get routing history for debugging/analysis
   */
  getRoutingHistory(limit: number = 100): typeof this.routingLog {
    return this.routingLog.slice(-limit);
  }

  /**
   * Get routing statistics for dashboard
   */
  getRoutingStats(): Record<string, any> {
    const agentCounts: Record<string, number> = {};
    const taskTypeCounts: Record<string, number> = {};

    this.routingLog.forEach((entry) => {
      agentCounts[entry.decision.primaryAgent] = (agentCounts[entry.decision.primaryAgent] || 0) + 1;
      // Reanalyze to get task type
      const analysis = this.analyzeIntent(entry.intent);
      taskTypeCounts[analysis.taskType] = (taskTypeCounts[analysis.taskType] || 0) + 1;
    });

    return {
      totalRoutedIntents: this.routingLog.length,
      agentDistribution: agentCounts,
      taskTypeDistribution: taskTypeCounts,
      averageComplexity: this.calculateAverageComplexity(),
    };
  }

  private calculateAverageComplexity(): number {
    if (this.routingLog.length === 0) return 0;
    const complexityMap = { quick: 1, urgent: 2, complex: 3 };
    const sum = this.routingLog.reduce((acc, entry) => {
      const analysis = this.analyzeIntent(entry.intent);
      return acc + complexityMap[analysis.complexity];
    }, 0);
    return sum / this.routingLog.length;
  }
}

interface IntentAnalysis {
  taskType: string;
  complexity: 'quick' | 'complex' | 'urgent';
  contextSize: number;
  requiresResearch: boolean;
  requiresCodeGeneration: boolean;
  requiresOrchestration: boolean;
}
