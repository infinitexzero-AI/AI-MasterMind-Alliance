/**
 * Mode 6 Agent Dispatcher
 * 
 * Implements multi-agent handoff protocol from multi-agent-sop.md
 * Manages agent availability, capability matching, and result verification
 */

import {
  AgentType,
  AgentCapabilities,
  HandoffContext,
  ExecutionResult,
  RoutingDecision,
} from '../intent-router/types';

export class AgentDispatcher {
  private agentCapabilities: Map<AgentType, AgentCapabilities>;
  private executionQueue: Array<{ decision: RoutingDecision; handoff: HandoffContext }> = [];
  private executionResults: Map<string, ExecutionResult> = new Map();

  constructor() {
    this.agentCapabilities = this.initializeCapabilities();
  }

  /**
   * Initialize agent capability matrix
   * Maps agent strengths to task types
   */
  private initializeCapabilities(): Map<AgentType, AgentCapabilities> {
    return new Map([
      [
        'supergrok',
        {
          agent: 'supergrok',
          primarySkills: ['orchestration', 'coordination', 'complex-logic', 'multi-agent-management'],
          secondarySkills: ['code-generation', 'analysis', 'research'],
          contextLimit: 200000,
          latencyProfile: 'standard',
          availableNow: true,
        },
      ],
      [
        'claude',
        {
          agent: 'claude',
          primarySkills: ['code-generation', 'analysis', 'documentation', 'reasoning'],
          secondarySkills: ['research', 'orchestration-support'],
          contextLimit: 200000,
          latencyProfile: 'standard',
          availableNow: true,
        },
      ],
      [
        'comet',
        {
          agent: 'comet',
          primarySkills: ['research', 'verification', 'web-browsing', 'fact-checking'],
          secondarySkills: ['analysis', 'summarization'],
          contextLimit: 100000,
          latencyProfile: 'high',
          availableNow: true,
        },
      ],
      [
        'chatgpt',
        {
          agent: 'chatgpt',
          primarySkills: ['github-integration', 'git-operations', 'automated-commits'],
          secondarySkills: ['code-review', 'documentation'],
          contextLimit: 128000,
          latencyProfile: 'standard',
          availableNow: true,
        },
      ],
    ]);
  }

  /**
   * Dispatch task to primary agent following handoff protocol
   * Returns execution promise that can be awaited or queued
   */
  async dispatchToAgent(
    decision: RoutingDecision,
    handoff: HandoffContext
  ): Promise<ExecutionResult> {
    try {
      // 1. Verify agent availability
      if (!this.isAgentAvailable(decision.primaryAgent)) {
        return this.handleUnavailableAgent(decision, handoff);
      }

      // 2. Validate context window fits agent capacity
      const capabilities = this.agentCapabilities.get(decision.primaryAgent)!;
      if (handoff.context.fullTaskDescription.length > capabilities.contextLimit) {
        return this.handleContextOverflow(decision, handoff);
      }

      // 3. Queue execution
      this.executionQueue.push({ decision, handoff });

      // 4. Simulate agent execution (in production: call actual agent API)
      const result = await this.executeTask(decision, handoff);

      // 5. Verify output meets expected format
      if (result.status === 'completed') {
        this.verifyOutput(result, handoff.expectedOutput);
      }

      // 6. Store result for cross-agent reference
      this.executionResults.set(decision.intentId, result);

      return result;
    } catch (error) {
      console.error(`Dispatch failed for ${decision.primaryAgent}:`, error);
      throw error;
    }
  }

  /**
   * Dispatch to secondary agent (multi-agent coordination)
   */
  async dispatchToSecondaryAgents(
    decision: RoutingDecision,
    handoff: HandoffContext
  ): Promise<ExecutionResult[]> {
    const results: ExecutionResult[] = [];

    for (const agent of decision.secondaryAgents) {
      try {
        // Create sub-handoff for secondary agent
        const subHandoff = this.createSubHandoff(handoff, agent);

        // Execute with secondary agent
        const result = await this.executeTask({ ...decision, primaryAgent: agent }, subHandoff);
        results.push(result);
      } catch (error) {
        console.error(`Secondary agent dispatch failed for ${agent}:`, error);
        results.push({
          taskId: decision.intentId,
          agent,
          status: 'failed',
          output: null,
          metadata: { executionTime: 0, errors: [`Dispatch failed: ${error}`] },
          timestamp: new Date().toISOString(),
        });
      }
    }

    return results;
  }

  /**
   * Simulate agent execution (placeholder for actual agent API calls)
   * In production: call Claude API, Grok API, etc.
   */
  private async executeTask(decision: RoutingDecision, handoff: HandoffContext): Promise<ExecutionResult> {
    const startTime = Date.now();

    // Simulate processing based on agent type
    const processingTime = this.estimateProcessingTime(decision.primaryAgent, handoff);
    await new Promise((resolve) => setTimeout(resolve, processingTime));

    const executionTime = Date.now() - startTime;

    // In production: replace with actual agent API response
    return {
      taskId: decision.intentId,
      agent: decision.primaryAgent,
      status: 'completed',
      output: {
        summary: `Completed by ${decision.primaryAgent}`,
        handoffFormat: handoff.format,
        timestamp: new Date().toISOString(),
      },
      metadata: {
        executionTime,
        tokensUsed: Math.floor(Math.random() * 5000) + 1000, // Mock value
        errors: [],
      },
      timestamp: new Date().toISOString(),
    };
  }

  /**
   * Estimate processing time based on agent and task complexity
   */
  private estimateProcessingTime(agent: AgentType, handoff: HandoffContext): number {
    const baseTime = 500; // 500ms base
    const contextFactor = Math.floor(handoff.context.fullTaskDescription.length / 1000);
    const agentLatencyMap = { instant: 0, standard: 200, high: 500 };

    const capabilities = this.agentCapabilities.get(agent)!;
    return baseTime + contextFactor * 50 + agentLatencyMap[capabilities.latencyProfile];
  }

  /**
   * Handle agent unavailability (from multi-agent-sop.md error handling)
   */
  private async handleUnavailableAgent(
    decision: RoutingDecision,
    handoff: HandoffContext
  ): Promise<ExecutionResult> {
    console.warn(`Agent ${decision.primaryAgent} unavailable, routing to backup`);

    // Get backup agent from mode routing
    const backupAgent = this.getBackupAgent(decision.primaryAgent);

    // Re-route to backup
    const backupDecision = { ...decision, primaryAgent: backupAgent };
    return this.executeTask(backupDecision, handoff);
  }

  /**
   * Handle context overflow (from multi-agent-sop.md error handling)
   */
  private async handleContextOverflow(
    decision: RoutingDecision,
    handoff: HandoffContext
  ): Promise<ExecutionResult> {
    console.warn(`Context overflow for ${decision.primaryAgent}, escalating`);

    return {
      taskId: decision.intentId,
      agent: decision.primaryAgent,
      status: 'escalated',
      output: {
        reason: 'context-overflow',
        escalationPath: decision.escalationPath,
        recommendation: 'Split task and re-delegate with summarized context',
      },
      metadata: {
        executionTime: 0,
        errors: ['Context window exceeded'],
      },
      timestamp: new Date().toISOString(),
    };
  }

  /**
   * Get backup agent based on mode routing table
   */
  private getBackupAgent(primaryAgent: AgentType): AgentType {
    const modeRoutingTable: Record<AgentType, AgentType> = {
      claude: 'supergrok',
      supergrok: 'comet',
      comet: 'claude',
      chatgpt: 'claude',
    };
    return modeRoutingTable[primaryAgent];
  }

  /**
   * Verify output matches expected format
   */
  private verifyOutput(result: ExecutionResult, expectedOutput: any): boolean {
    if (expectedOutput.format === 'structured-result' && typeof result.output !== 'object') {
      console.warn(`Output format mismatch: expected ${expectedOutput.format}`);
      return false;
    }
    if (expectedOutput.includeMetadata && !result.metadata) {
      console.warn('Expected metadata missing from output');
      return false;
    }
    return true;
  }

  /**
   * Create sub-handoff for secondary agents
   */
  private createSubHandoff(parentHandoff: HandoffContext, secondaryAgent: AgentType): HandoffContext {
    return {
      ...parentHandoff,
      format: `${parentHandoff.format.split('→')[0]} → [${secondaryAgent.toUpperCase()}]`,
      context: {
        ...parentHandoff.context,
        parentHandoff: parentHandoff.format,
        coordinationType: 'secondary-verification',
      },
    };
  }

  /**
   * Check if agent is currently available
   */
  private isAgentAvailable(agent: AgentType): boolean {
    const capabilities = this.agentCapabilities.get(agent);
    return capabilities ? capabilities.availableNow : false;
  }

  /**
   * Get execution result by task ID
   */
  getExecutionResult(taskId: string): ExecutionResult | undefined {
    return this.executionResults.get(taskId);
  }

  /**
   * Get dispatcher statistics for dashboard
   */
  getDispatcherStats(): Record<string, any> {
    const completedTasks = Array.from(this.executionResults.values()).filter(
      (r) => r.status === 'completed'
    ).length;
    const failedTasks = Array.from(this.executionResults.values()).filter(
      (r) => r.status === 'failed'
    ).length;

    return {
      totalExecutions: this.executionResults.size,
      completedTasks,
      failedTasks,
      queueLength: this.executionQueue.length,
      agentCapabilities: Array.from(this.agentCapabilities.entries()).map(([agent, caps]) => ({
        agent,
        skills: caps.primarySkills,
        contextLimit: caps.contextLimit,
        available: caps.availableNow,
      })),
    };
  }
}
