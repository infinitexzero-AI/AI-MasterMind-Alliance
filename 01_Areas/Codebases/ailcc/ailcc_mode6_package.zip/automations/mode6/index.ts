/**
 * Mode 6 Entry Point
 * Exports core orchestration components
 * 
 * Usage:
 * import { Mode6Orchestrator } from './automations/mode6';
 * const orchestrator = new Mode6Orchestrator();
 */

export { IntentRouter } from './intent-router/intent-router';
export type {
  TaskIntent,
  RoutingDecision,
  HandoffContext,
  ExecutionResult,
  MemoryEntry,
  AgentCapabilities,
} from './intent-router/types';

export { AgentDispatcher } from '../mode6/agent-routing/agent-dispatcher';
export { MemoryManager } from '../mode6/memory/memory-manager';

/**
 * Mode6Orchestrator
 * Main orchestration class that coordinates all components
 */
export class Mode6Orchestrator {
  private dispatcher: AgentDispatcher;
  private memory: MemoryManager;
  private router: IntentRouter;

  constructor() {
    this.dispatcher = new AgentDispatcher();
    this.memory = new MemoryManager();
    this.router = new IntentRouter(this.dispatcher, this.memory);
  }

  /**
   * Main entry point for task orchestration
   */
  async processTask(intent: any): Promise<any> {
    // 1. Route intent to appropriate agent(s)
    const handoff = await this.router.routeIntent(intent);

    // 2. Dispatch to primary agent
    const result = await this.dispatcher.dispatchToAgent(
      // Extract routing decision from router
      {
        intentId: intent.id,
        primaryAgent: 'claude', // Would be extracted from router
        secondaryAgents: [],
        reasoning: 'Orchestrated by Mode 6',
        escalationPath: 'human-review',
        contextWindowRequired: intent.description.length,
      },
      handoff
    );

    // 3. Store result in memory
    await this.memory.storeExecutionResult(result);

    return result;
  }

  /**
   * Get system statistics for monitoring
   */
  getSystemStats(): Record<string, any> {
    return {
      routing: this.router.getRoutingStats(),
      dispatcher: this.dispatcher.getDispatcherStats(),
      memory: this.memory.getMemoryStats(),
    };
  }

  /**
   * Get execution result by task ID
   */
  getResult(taskId: string): any {
    return this.dispatcher.getExecutionResult(taskId);
  }

  /**
   * Trigger memory cleanup
   */
  async cleanup(): Promise<Record<string, any>> {
    return this.memory.applyRetentionPolicy();
  }
}
