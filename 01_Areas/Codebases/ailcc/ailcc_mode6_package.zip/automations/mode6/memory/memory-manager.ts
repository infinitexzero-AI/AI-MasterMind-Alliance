/**
 * Mode 6 Memory Manager
 * 
 * Maintains cross-agent context persistence across task execution
 * Enables secondary agents to reference primary agent output
 * Implements memory policies for cleanup and archival
 */

import { MemoryEntry, ExecutionResult, TaskIntent } from '../intent-router/types';

export class MemoryManager {
  private memoryStore: Map<string, MemoryEntry[]> = new Map();
  private taskGraph: Map<string, Set<string>> = new Map(); // Task dependencies
  private readyForGC: Set<string> = new Set(); // Tasks ready for garbage collection

  /**
   * Store a memory entry from agent execution
   */
  async storeMemoryEntry(entry: MemoryEntry): Promise<void> {
    const entries = this.memoryStore.get(entry.taskId) || [];
    entries.push(entry);
    this.memoryStore.set(entry.taskId, entries);

    console.log(`[Memory] Stored entry for task ${entry.taskId} from ${entry.agent}`);
  }

  /**
   * Store complete routing decision for reference by subsequent agents
   */
  async storeRoutingDecision(decision: any): Promise<void> {
    const entry: MemoryEntry = {
      id: `routing-${decision.intentId}`,
      taskId: decision.intentId,
      agent: 'router',
      context: {
        primaryAgent: decision.primaryAgent,
        secondaryAgents: decision.secondaryAgents,
        reasoning: decision.reasoning,
        escalationPath: decision.escalationPath,
      },
      relationshipType: 'prerequisite',
      createdAt: new Date().toISOString(),
    };

    await this.storeMemoryEntry(entry);
  }

  /**
   * Retrieve all context related to a task
   * Used by router for handoff preparation
   */
  async retrieveRelatedContext(taskId: string): Promise<Record<string, any>> {
    const entries = this.memoryStore.get(taskId) || [];
    const context: Record<string, any> = {};

    entries.forEach((entry) => {
      context[`${entry.agent}-${entry.relationshipType}`] = entry.context;
    });

    return context;
  }

  /**
   * Retrieve context from related/prerequisite tasks
   * Enables agents to reference previous work
   */
  async retrievePrerequisiteContext(taskId: string): Promise<Record<string, any>> {
    const entries = this.memoryStore.get(taskId) || [];
    const prerequisiteContext: Record<string, any> = {};

    entries.forEach((entry) => {
      if (entry.relationshipType === 'prerequisite') {
        prerequisiteContext[entry.id] = entry.context;
      }
    });

    return prerequisiteContext;
  }

  /**
   * Retrieve follow-up tasks (for cascade execution)
   */
  async retrieveFollowUpTasks(taskId: string): Promise<TaskIntent[]> {
    const entries = this.memoryStore.get(taskId) || [];
    const followUps = entries.filter((e) => e.relationshipType === 'follow-up');

    return followUps.map((entry) => ({
      id: entry.id,
      description: entry.context.description || 'Follow-up task',
      priority: entry.context.priority || 'medium',
      mode: entry.context.mode || 'mode-6',
      createdAt: entry.createdAt,
    }));
  }

  /**
   * Store execution result with memory linkage
   */
  async storeExecutionResult(result: ExecutionResult, relatedTaskIds: string[] = []): Promise<void> {
    const entry: MemoryEntry = {
      id: `exec-${result.taskId}`,
      taskId: result.taskId,
      agent: result.agent,
      context: {
        status: result.status,
        output: result.output,
        executionTime: result.metadata.executionTime,
        errors: result.metadata.errors,
      },
      relationshipType: 'related',
      createdAt: result.timestamp,
    };

    await this.storeMemoryEntry(entry);

    // Build task graph for dependency tracking
    this.buildTaskDependencies(result.taskId, relatedTaskIds);
  }

  /**
   * Build task dependency graph
   * Helps identify cleanup candidates and cascade operations
   */
  private buildTaskDependencies(taskId: string, dependencies: string[]): void {
    const dependentSet = this.taskGraph.get(taskId) || new Set();
    dependencies.forEach((dep) => dependentSet.add(dep));
    this.taskGraph.set(taskId, dependentSet);
  }

  /**
   * Apply memory retention policies
   * Called periodically to clean up old entries and archive completed tasks
   */
  async applyRetentionPolicy(): Promise<{ archived: number; deleted: number }> {
    const now = new Date();
    let archived = 0;
    let deleted = 0;

    const entriesToDelete: string[] = [];

    // Iterate through all stored entries
    for (const [taskId, entries] of this.memoryStore.entries()) {
      entries.forEach((entry, index) => {
        // Check expiration
        if (entry.expiresAt && new Date(entry.expiresAt) < now) {
          entriesToDelete.push(`${taskId}-${index}`);
          deleted++;
        }

        // Check age for archival (older than 30 days)
        const entryAge = now.getTime() - new Date(entry.createdAt).getTime();
        const thirtyDaysMs = 30 * 24 * 60 * 60 * 1000;

        if (entryAge > thirtyDaysMs) {
          console.log(`[Memory] Archiving entry ${entry.id} (age: ${Math.floor(entryAge / (1000 * 60 * 60))}h)`);
          archived++;
          entriesToDelete.push(`${taskId}-${index}`);
        }
      });
    }

    // Remove expired entries
    entriesToDelete.forEach((key) => {
      const [taskId, indexStr] = key.split('-');
      const index = parseInt(indexStr);
      const entries = this.memoryStore.get(taskId);
      if (entries) {
        entries.splice(index, 1);
      }
    });

    console.log(`[Memory] Retention policy applied: ${archived} archived, ${deleted} deleted`);
    return { archived, deleted };
  }

  /**
   * Get memory statistics for dashboard
   */
  getMemoryStats(): Record<string, any> {
    let totalEntries = 0;
    let totalTasks = 0;
    const agentDistribution: Record<string, number> = {};

    for (const [taskId, entries] of this.memoryStore.entries()) {
      totalTasks++;
      totalEntries += entries.length;

      entries.forEach((entry) => {
        agentDistribution[entry.agent] = (agentDistribution[entry.agent] || 0) + 1;
      });
    }

    const estimatedMemoryMB = (
      totalEntries * 1024 + // Rough estimate: ~1KB per entry
      totalTasks * 512
    ) / (1024 * 1024);

    return {
      totalEntries,
      totalTasks,
      agentDistribution,
      estimatedMemoryMB,
      taskGraphSize: this.taskGraph.size,
      readyForGC: this.readyForGC.size,
    };
  }

  /**
   * Get entry count for a specific task
   */
  getTaskMemoryFootprint(taskId: string): number {
    const entries = this.memoryStore.get(taskId) || [];
    return entries.reduce((sum, entry) => sum + JSON.stringify(entry).length, 0);
  }

  /**
   * Retrieve complete memory dump for debugging
   */
  getMemoryDump(taskId?: string): Record<string, any> {
    if (taskId) {
      return {
        taskId,
        entries: this.memoryStore.get(taskId) || [],
        dependencies: Array.from(this.taskGraph.get(taskId) || new Set()),
      };
    }

    return {
      totalMemory: {
        entries: Array.from(this.memoryStore.entries()).map(([taskId, entries]) => ({
          taskId,
          entryCount: entries.length,
        })),
      },
      taskGraph: Object.fromEntries(
        Array.from(this.taskGraph.entries()).map(([taskId, deps]) => [
          taskId,
          Array.from(deps),
        ])
      ),
    };
  }
}
