# Mode 6 Intent Routing System

**Status**: Hybrid Implementation (Core systems complete, UI/API scaffolded)  
**Last Updated**: November 26, 2025

## Overview

Mode 6 is the **Intent Routing & Multi-Agent Orchestration** layer that extends the AILCC 5-mode model with intelligent task distribution, cross-agent coordination, and persistent memory management.

### Key Components

1. **Intent Router** — Analyzes tasks and routes to optimal agent
2. **Agent Dispatcher** — Executes handoffs following multi-agent-sop.md protocol
3. **Memory Manager** — Maintains cross-agent context persistence
4. **Dashboard UI** — Real-time routing visualization (scaffolded)
5. **API Routes** — REST endpoints for integration (scaffolded)

## Architecture

```
Linear/User Input
    ↓
[Intent Router] — Analyzes task, classifies complexity, selects agent
    ↓
[Memory Manager] — Retrieves related context, prerequisite tasks
    ↓
[Agent Dispatcher] — Routes to primary/secondary agents using multi-agent-sop.md
    ↓
[Agent Execution] — SuperGrok, Claude, Comet, ChatGPT execute in parallel
    ↓
[Result Verification] — Validate output, log execution
    ↓
[Memory Storage] — Store result + build task dependency graph
    ↓
Dashboard → Real-time stats, routing history, memory metrics
```

## Mode 6 Positioning

| Component | Mode 1-5 Role | Mode 6 Enhancement |
|-----------|--------------|-------------------|
| Task Definition | Linear/Manual | Auto-routed by intent analysis |
| Agent Selection | Manual | Automatic capability matching |
| Handoff Protocol | Documented | Enforced by Agent Dispatcher |
| Cross-Agent Context | Implicit | Explicit via Memory Manager |
| Monitoring | Dashboard | Real-time routing + task graph visualization |

## How It Works

### 1. Intent Analysis (IntentRouter)

```typescript
const intent = {
  id: "LINEAR-123",
  description: "Implement authentication system with Claude analysis",
  subtasks: ["Design schema", "Generate code", "Write tests"],
  priority: "high",
  mode: "automation"
};

const decision = await intentRouter.routeIntent(intent);
// → Selects Claude (code generation) + Comet (research verification)
// → Prepares multi-agent handoff context
```

**Router classifies tasks by**:
- Task type (orchestration, research, development, github-integration, analysis)
- Complexity (quick, complex, urgent)
- Context requirements
- Multi-agent needs

### 2. Agent Routing (AgentDispatcher)

Routes using capability matrix from `multi-agent-sop.md`:

| Agent | Primary Skills | Best For |
|-------|---|---|
| **SuperGrok** | Orchestration, coordination, complex logic | Multi-step tasks, delegating to other agents |
| **Claude** | Code generation, analysis, reasoning | Development, detailed problem-solving |
| **Comet** | Research, verification, web browsing | Fact-checking, external data retrieval |
| **ChatGPT** | GitHub integration, git operations | Commits, branch management, automation |

**Handoff Protocol** (from `docs/sops/multi-agent-sop.md`):
```
Format: [SOURCE_AGENT] → [TARGET_AGENT]
Context: Full task description + prerequisite context
Expected Output: Structured result with metadata
Escalation Route: Context overflow → split + re-delegate
```

### 3. Cross-Agent Memory (MemoryManager)

Stores execution context so secondary agents can reference primary agent output:

```typescript
// Primary agent (Claude) generates code
const result = await dispatcher.dispatchToAgent(decision, handoff);

// Store result in memory with task linkage
await memory.storeExecutionResult(result, relatedTasks);

// Secondary agent (Comet) retrieves for verification
const context = await memory.retrieveRelatedContext(taskId);
```

**Memory Relationships**:
- `prerequisite` — Must complete before next task
- `related` — Associated context from same workflow
- `follow-up` — Cascade tasks after completion
- `escalation` — Error recovery / alternate paths

### 4. Retention Policies

Memory entries:
- Expire based on TTL
- Archive after 30 days
- Cleaned up by `applyRetentionPolicy()`
- Task dependency graph prevents orphaned data

## File Structure

```
automations/mode6/
├── intent-router/
│   ├── intent-router.ts      # Core routing engine ✅
│   └── types.ts              # Shared TypeScript interfaces ✅
├── agent-routing/
│   └── agent-dispatcher.ts   # Multi-agent handoff coordination ✅
├── memory/
│   └── memory-manager.ts     # Cross-agent context storage ✅
└── README.md                 # This file

dashboard/                     # Next.js UI (scaffolded)
├── app/
│   └── page.tsx              # Main dashboard
├── components/
│   ├── routing-stats.tsx      # Routing statistics panel
│   ├── task-graph.tsx         # Task dependency visualization
│   └── memory-metrics.tsx     # Memory usage display
└── api/
    ├── routing/stats.ts       # GET /api/routing/stats
    ├── agent/capabilities.ts  # GET /api/agent/capabilities
    └── memory/metrics.ts      # GET /api/memory/metrics
```

## Integration Steps

### 1. Installation

```bash
# Clone the branch
git clone <repo> --branch feature/mode-6

# Install dependencies (when project structure is finalized)
npm install
```

### 2. Initialize Core Components

```typescript
import { IntentRouter } from './automations/mode6/intent-router/intent-router';
import { AgentDispatcher } from './automations/mode6/agent-routing/agent-dispatcher';
import { MemoryManager } from './automations/mode6/memory/memory-manager';

const dispatcher = new AgentDispatcher();
const memory = new MemoryManager();
const router = new IntentRouter(dispatcher, memory);
```

### 3. Route Tasks

```typescript
const intent = {
  id: 'task-123',
  description: 'Analyze performance data and generate report',
  priority: 'high',
  mode: 'automation',
  createdAt: new Date().toISOString(),
};

const handoff = await router.routeIntent(intent);
const result = await dispatcher.dispatchToAgent(
  // routing decision passed from router
  handoff
);
```

### 4. Monitor Dashboard

Access real-time metrics:
- Routing history with reasoning
- Agent distribution across tasks
- Task complexity patterns
- Memory footprint and retention
- Execution times and success rates

## API Endpoints (Scaffolded)

```bash
# Get routing statistics
GET /api/routing/stats
→ { totalRoutedIntents, agentDistribution, taskTypeDistribution }

# Get agent capabilities
GET /api/agent/capabilities
→ { agents: [{ agent, skills, contextLimit, available }] }

# Get memory metrics
GET /api/memory/metrics
→ { totalEntries, totalTasks, agentDistribution, estimatedMemoryMB }

# Get execution result
GET /api/execution/:taskId
→ { taskId, agent, status, output, metadata }

# Trigger memory cleanup
POST /api/memory/cleanup
→ { archived, deleted }
```

## Integration with Existing AILCC Components

### With multi-agent-sop.md

Mode 6 **enforces** the handoff protocol:
- Validates handoff format: `[SOURCE] → [TARGET]`
- Enforces context preservation across agents
- Implements escalation paths from error handling section
- Logs all delegations for audit trail

### With Prompts

Mode 6 works alongside agent-specific prompts:
- `prompts/supergrok/` — Orchestration training receives Mode 6 routing context
- `prompts/claude/` — Code generation gets prerequisite context from Memory Manager
- `prompts/comet/` — Research tasks receive related context for faster verification
- `prompts/chatgpt/` — GitHub integration receives execution results to commit

### With Existing Modes (1-5)

Mode 6 **enhances** without replacing:
- **Student Mode**: Tasks auto-routed to Claude + Comet for verification
- **Professional Mode**: Orchestrated through SuperGrok for career task sequencing
- **Life Mode**: Comet-first for personal productivity research
- **Self-Actualized Mode**: SuperGrok coordination for meta-learning workflows
- **Automation Mode**: Full Mode 6 routing for CI/CD and workflow automation

## Performance Characteristics

| Metric | Target | Notes |
|--------|--------|-------|
| Intent Analysis | <100ms | Classifies task type, complexity |
| Agent Selection | <50ms | Matches capabilities to requirements |
| Handoff Preparation | <200ms | Includes memory context retrieval |
| Total Routing Latency | <500ms | End-to-end before agent execution |
| Memory Lookup | <50ms | Task graph traversal |
| Task Dependency Building | O(n) | Linear with subtask count |

## Testing & Validation

### Unit Tests (TODO)
```bash
npm test -- intent-router.test.ts
npm test -- agent-dispatcher.test.ts
npm test -- memory-manager.test.ts
```

### Integration Tests (TODO)
```bash
npm test -- mode6.integration.test.ts
```

### Load Testing (TODO)
```bash
npm run load-test -- --agents 4 --tasks 1000 --concurrency 10
```

## Future Enhancements

- [ ] Implement actual agent API calls (currently mocked)
- [ ] Dashboard UI completion (Next.js)
- [ ] API endpoint implementation
- [ ] Persistent storage (PostgreSQL) instead of in-memory
- [ ] Real-time WebSocket updates for dashboard
- [ ] Machine learning for routing optimization
- [ ] A/B testing for routing decisions
- [ ] Multi-region agent distribution

## Documentation References

- **Branch Strategy**: See `/docs/sops/multi-agent-sop.md` for routing table
- **Agent Capabilities**: See `copilot-instructions.md` → "Agent routing by capability"
- **Mode-Specific Routing**: See `multi-agent-sop.md` → "Mode-Specific Routing" table
- **Error Handling**: See `multi-agent-sop.md` → "Error Handling" section

## Contributing

When extending Mode 6:

1. Follow naming conventions: `{component}-{purpose}.ts`
2. Maintain cross-agent handoff format
3. Update memory manager for new context types
4. Add tests for new routing rules
5. Document in README before PR

---

**Created**: November 26, 2025  
**Part of**: AILCC Framework v1  
**Branch**: `feature/mode-6`
