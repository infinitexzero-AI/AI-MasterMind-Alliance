/**
 * Routing Statistics Component
 * Displays real-time routing decisions and agent selection patterns
 * 
 * TODO: Implement:
 * - Live WebSocket connection for real-time updates
 * - Filtering and sorting controls
 * - Export routing history to CSV
 * - Routing decision reasoning details
 */

'use client';

import React, { useState, useEffect } from 'react';

interface RoutingHistoryEntry {
  timestamp: string;
  intentId: string;
  taskType: string;
  primaryAgent: string;
  secondaryAgents: string[];
  complexity: string;
}

export function RoutingStatsComponent() {
  const [history, setHistory] = useState<RoutingHistoryEntry[]>([]);
  const [filter, setFilter] = useState<string>('all');

  useEffect(() => {
    // TODO: Connect to WebSocket for real-time updates
    // const ws = new WebSocket('ws://localhost:8000/routing-updates');
    // ws.onmessage = (event) => {
    //   setHistory(prev => [JSON.parse(event.data), ...prev].slice(0, 100));
    // };
  }, []);

  const mockHistory: RoutingHistoryEntry[] = [
    {
      timestamp: new Date().toISOString(),
      intentId: 'INT-001',
      taskType: 'development',
      primaryAgent: 'claude',
      secondaryAgents: ['comet'],
      complexity: 'complex',
    },
    {
      timestamp: new Date(Date.now() - 60000).toISOString(),
      intentId: 'INT-002',
      taskType: 'research',
      primaryAgent: 'comet',
      secondaryAgents: [],
      complexity: 'quick',
    },
  ];

  return (
    <div className="bg-white rounded-lg shadow overflow-hidden">
      <div className="px-6 py-4 border-b border-gray-200">
        <h3 className="text-lg font-semibold text-gray-900">Recent Routing Decisions</h3>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">
                Time
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">
                Intent ID
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">
                Task Type
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">
                Primary Agent
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">
                Secondary
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">
                Complexity
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {mockHistory.map((entry, idx) => (
              <tr key={idx} className="hover:bg-gray-50">
                <td className="px-6 py-4 text-sm text-gray-700">
                  {new Date(entry.timestamp).toLocaleTimeString()}
                </td>
                <td className="px-6 py-4 text-sm text-gray-700 font-mono">{entry.intentId}</td>
                <td className="px-6 py-4 text-sm text-gray-700">{entry.taskType}</td>
                <td className="px-6 py-4 text-sm">
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800">
                    {entry.primaryAgent}
                  </span>
                </td>
                <td className="px-6 py-4 text-sm">
                  {entry.secondaryAgents.length > 0 ? (
                    <span className="text-gray-600">{entry.secondaryAgents.join(', ')}</span>
                  ) : (
                    <span className="text-gray-400">None</span>
                  )}
                </td>
                <td className="px-6 py-4 text-sm">
                  <span
                    className={`inline-flex items-center px-2 py-1 rounded text-xs font-medium ${
                      entry.complexity === 'complex'
                        ? 'bg-red-100 text-red-800'
                        : entry.complexity === 'urgent'
                          ? 'bg-orange-100 text-orange-800'
                          : 'bg-green-100 text-green-800'
                    }`}
                  >
                    {entry.complexity}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="px-6 py-4 bg-gray-50 border-t border-gray-200">
        <p className="text-sm text-gray-600">
          TODO: Implement real-time updates, filtering, and routing reasoning details
        </p>
      </div>
    </div>
  );
}
