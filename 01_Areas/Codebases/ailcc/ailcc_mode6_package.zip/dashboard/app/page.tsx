/**
 * Dashboard Main Page
 * Real-time Mode 6 routing visualization and metrics
 * 
 * TODO: Replace with working implementation
 * - Connect to Mode 6 API endpoints
 * - Implement WebSocket for real-time updates
 * - Add interactive task graph visualization
 */

'use client';

import React, { useState, useEffect } from 'react';

interface DashboardMetrics {
  routing: {
    totalRoutedIntents: number;
    agentDistribution: Record<string, number>;
    taskTypeDistribution: Record<string, number>;
  };
  dispatcher: {
    totalExecutions: number;
    completedTasks: number;
    failedTasks: number;
    queueLength: number;
  };
  memory: {
    totalEntries: number;
    totalTasks: number;
    agentDistribution: Record<string, number>;
    estimatedMemoryMB: number;
  };
}

export default function Dashboard() {
  const [metrics, setMetrics] = useState<DashboardMetrics | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // TODO: Connect to real API endpoints
    fetchMetrics();
    const interval = setInterval(fetchMetrics, 5000); // Refresh every 5 seconds

    return () => clearInterval(interval);
  }, []);

  const fetchMetrics = async () => {
    try {
      setLoading(true);
      // TODO: Replace with actual API calls
      // const routingStats = await fetch('/api/routing/stats');
      // const dispatcherStats = await fetch('/api/dispatcher/stats');
      // const memoryMetrics = await fetch('/api/memory/metrics');

      // Mock data for demonstration
      const mockMetrics: DashboardMetrics = {
        routing: {
          totalRoutedIntents: 24,
          agentDistribution: {
            supergrok: 5,
            claude: 12,
            comet: 4,
            chatgpt: 3,
          },
          taskTypeDistribution: {
            development: 10,
            research: 4,
            orchestration: 6,
            'github-integration': 4,
          },
        },
        dispatcher: {
          totalExecutions: 24,
          completedTasks: 22,
          failedTasks: 1,
          queueLength: 3,
        },
        memory: {
          totalEntries: 156,
          totalTasks: 24,
          agentDistribution: {
            claude: 42,
            comet: 28,
            supergrok: 35,
            router: 51,
          },
          estimatedMemoryMB: 0.15,
        },
      };

      setMetrics(mockMetrics);
      setError(null);
    } catch (err) {
      setError(`Failed to fetch metrics: ${err}`);
      console.error('Metrics fetch error:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading && !metrics) {
    return <div className="p-8">Loading dashboard...</div>;
  }

  if (error && !metrics) {
    return <div className="p-8 text-red-600">Error: {error}</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Mode 6 Control Center</h1>
        <p className="text-gray-600">Real-time intent routing and multi-agent orchestration</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {/* Routing Stats Card */}
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-sm font-medium text-gray-500 mb-2">Routed Intents</h3>
          <p className="text-3xl font-bold text-gray-900">
            {metrics?.routing.totalRoutedIntents || 0}
          </p>
          <p className="text-xs text-gray-400 mt-2">Last 24 hours</p>
        </div>

        {/* Completed Tasks Card */}
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-sm font-medium text-gray-500 mb-2">Completed Tasks</h3>
          <p className="text-3xl font-bold text-green-600">
            {metrics?.dispatcher.completedTasks || 0}
          </p>
          <p className="text-xs text-gray-400 mt-2">Success rate: 91.7%</p>
        </div>

        {/* Queue Length Card */}
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-sm font-medium text-gray-500 mb-2">Pending Queue</h3>
          <p className="text-3xl font-bold text-blue-600">
            {metrics?.dispatcher.queueLength || 0}
          </p>
          <p className="text-xs text-gray-400 mt-2">Tasks waiting execution</p>
        </div>

        {/* Memory Usage Card */}
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-sm font-medium text-gray-500 mb-2">Memory Usage</h3>
          <p className="text-3xl font-bold text-purple-600">
            {(metrics?.memory.estimatedMemoryMB || 0).toFixed(2)} MB
          </p>
          <p className="text-xs text-gray-400 mt-2">Across {metrics?.memory.totalTasks || 0} tasks</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Agent Distribution */}
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Agent Distribution</h2>
          <div className="space-y-3">
            {metrics?.routing.agentDistribution &&
              Object.entries(metrics.routing.agentDistribution).map(([agent, count]) => (
                <div key={agent}>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium text-gray-700">{agent}</span>
                    <span className="text-sm text-gray-600">{count} tasks</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-blue-600 h-2 rounded-full"
                      style={{
                        width: `${(count / (metrics.routing.totalRoutedIntents || 1)) * 100}%`,
                      }}
                    ></div>
                  </div>
                </div>
              ))}
          </div>
        </div>

        {/* Task Type Distribution */}
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Task Type Distribution</h2>
          <div className="space-y-3">
            {metrics?.routing.taskTypeDistribution &&
              Object.entries(metrics.routing.taskTypeDistribution).map(([taskType, count]) => (
                <div key={taskType}>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium text-gray-700">{taskType}</span>
                    <span className="text-sm text-gray-600">{count} tasks</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-green-600 h-2 rounded-full"
                      style={{
                        width: `${(count / (metrics.routing.totalRoutedIntents || 1)) * 100}%`,
                      }}
                    ></div>
                  </div>
                </div>
              ))}
          </div>
        </div>
      </div>

      {/* TODO: Add sections below */}
      <div className="mt-8 bg-yellow-50 border border-yellow-200 rounded-lg p-6">
        <h3 className="font-semibold text-yellow-900 mb-2">TODO: Incomplete Sections</h3>
        <ul className="list-disc list-inside text-yellow-800 text-sm space-y-1">
          <li>Task Dependency Graph visualization</li>
          <li>Routing history timeline</li>
          <li>Real-time WebSocket updates</li>
          <li>Agent capability details modal</li>
          <li>Memory retention policy controls</li>
          <li>Performance analytics</li>
        </ul>
      </div>
    </div>
  );
}
